package ArrayLecture;
import java.util.ArrayList;
public class ArrayListExample {
    public static void main(String[] args) {
        ArrayList myList= new ArrayList();
        myList.add("car");
        myList.add(25.5);
        myList.add('c');
        myList.remove(0);
        for(int i=0;i<myList.size();i++)
        {
            System.out.println(myList.get(i));
        }
        for(var i:myList)
        {
            System.out.println(i);
        }
        myList.set(0,95.6);
        myList.clear();;
//Wrapper Class
        ArrayList<Double> intList=new ArrayList<>();
        intList.add(25.0);

        ArrayList<Rider> riderList=new ArrayList<>();
        riderList.add(new Rider("Joy",35));
        System.out.println(riderList.get(0).getName());
        System.out.println(riderList.get(0).getAge());



    }
}
