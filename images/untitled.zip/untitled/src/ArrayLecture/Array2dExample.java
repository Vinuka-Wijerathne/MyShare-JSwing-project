package ArrayLecture;

public class Array2dExample {
    public static void main(String[] args) {
        int[][] A={{25,65},{75,85}};//method 1
        int[][] B=new int[2][2];
        System.out.println(B[0][0]);
        B[0][0]=25;
        B[0][1]=65;
        B[1][0]=75;
        B[1][1]=85;
        for (int i=0;i<B.length;i++)//rows
        {
            for (int j=0;j<B[i].length;j++)//columns
            {
                System.out.print(B[i][j]+"\t");
            }
            System.out.println();

        }
        int C[][]=new int[][]{{25,65},{75,85}};//method 3
        int[][] D={{10,20},{15},{60,50,12}};//method 1
        int[][] E=new int[3][];//setting row count
        //setting number of columns
        E[0]=new int[2];
        E[1]=new int[1];
        E[2]=new int[3];
        //setting values
        E[0][0]=10;
        E[0][1]=20;
        E[1][0]=15;
        E[2][0]=60;
        E[2][1]=50;
        E[2][2]=12;



    }
}
