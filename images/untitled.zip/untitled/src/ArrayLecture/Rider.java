package ArrayLecture;

public class Rider {
    private String Name;
    private int Age;

    public Rider(String name, int age) {
        Name = name;
        Age = age;
    }
    public int getAge() //getter of age
    {
        return Age;
    }
    public void setAge(int Age) //setter
    {
        this.Age=Age;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }
}
