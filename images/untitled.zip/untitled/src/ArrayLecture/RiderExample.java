package ArrayLecture;

public class RiderExample {
    public static void main(String[] args) {
       RiderExample e=new RiderExample();
       Rider[] riderList=e.createRiders();
        for(Rider i:riderList)
        {
            System.out.println(i.getName());
            System.out.println(i.getAge());
        }

    }
   private Rider[] createRiders()
    {
        Rider[] riderList=new Rider[3];
        riderList[0]=new Rider("Tom",45);
        riderList[1]=new Rider("Joy",45);
        riderList[2]=new Rider("Lance",45);
        return riderList;
    }
}
