package ArrayLecture;

public class ArrayExample {

    public static void main(String[] args) {
        int[]  A={95,25,63};//method 1
        {
            int[] B = new int[3];//method 2
            B[0] = 95;
            B[1] = 25;
            B[2] = 63;
            int[] C = new int[]{10, 25, 63};//method 3
            for (int i = 0; i < B.length; i++) {
                System.out.println(B[i]);
            }
            for (int i : B)//enhanced for loop
            {
                System.out.println(i);
            }

        }
        ArrayExample e = new ArrayExample();
        e.Change(A);
        System.out.println(A[0]);
    }
    void Change(int[] A)//Pass by Reference
    {
        A[0]=25;
    }


}
